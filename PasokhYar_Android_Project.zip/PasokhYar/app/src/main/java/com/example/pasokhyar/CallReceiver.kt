package com.example.pasokhyar

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import android.telephony.SubscriptionManager
import android.telephony.PhoneNumberUtils
import android.util.Log

class CallReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return
        if (context.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return

        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER).orEmpty()
        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                prefs.edit().putBoolean("wasRinging", true)
                    .putBoolean("wasAnswered", false)
                    .putString("incomingNumber", number)
                    .apply()
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                if (prefs.getBoolean("wasRinging", false)) prefs.edit().putBoolean("wasAnswered", true).apply()
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                val ringing = prefs.getBoolean("wasRinging", false)
                val answered = prefs.getBoolean("wasAnswered", false)
                val caller = (intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                    ?: prefs.getString("incomingNumber", "")).orEmpty()
                prefs.edit().putBoolean("wasRinging", false).putBoolean("wasAnswered", false)
                    .remove("incomingNumber").apply()
                if (ringing && !answered && caller.isNotBlank()) sendReply(context, prefs, caller)
            }
        }
    }

    private fun sendReply(context: Context, prefs: android.content.SharedPreferences, number: String) {
        try {
            val subId = prefs.getInt("subId", SubscriptionManager.getDefaultSmsSubscriptionId())
            val sms = if (subId >= 0) SmsManager.getSmsManagerForSubscriptionId(subId) else SmsManager.getDefault()
            val body = prefs.getString("message", MainActivity.DEFAULT_MESSAGE).orEmpty()
            if (body.isBlank()) return
            val parts = sms.divideMessage(body)
            if (parts.size > 1) sms.sendMultipartTextMessage(number, null, parts, null, null)
            else sms.sendTextMessage(number, null, body, null, null)
        } catch (e: Exception) {
            Log.e("PasokhYar", "SMS send failed", e)
        }
    }
}
