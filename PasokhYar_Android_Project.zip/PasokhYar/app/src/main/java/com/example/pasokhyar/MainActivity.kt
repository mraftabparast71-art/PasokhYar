package com.example.pasokhyar

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.widget.*
import android.graphics.Typeface
import android.view.ViewGroup

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("settings", Context.MODE_PRIVATE) }
    private lateinit var message: EditText
    private lateinit var enabled: Switch
    private lateinit var sim: Spinner
    private var subscriptions: List<android.telephony.SubscriptionInfo> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (!hasPermissions()) requestPermissions(
            arrayOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.SEND_SMS, Manifest.permission.READ_PHONE_NUMBERS), 100
        )
        loadSims()
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 24)
        }
        val title = TextView(this).apply {
            text = "پاسخ‌یار"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
        }
        layout.addView(title)
        layout.addView(TextView(this).apply {
            text = "وقتی نتوانستی تماس را جواب بدهی، پیامک آماده برای تماس‌گیرنده ارسال می‌شود."
            textSize = 16f
            setPadding(0, 12, 0, 24)
        })
        enabled = Switch(this).apply {
            text = "ارسال خودکار پیامک فعال باشد"
            isChecked = prefs.getBoolean("enabled", false)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("enabled", checked).apply() }
        }
        layout.addView(enabled)
        layout.addView(TextView(this).apply { text = "متن پیامک"; textSize = 18f; setPadding(0, 24, 0, 8) })
        message = EditText(this).apply {
            minLines = 4
            gravity = android.view.Gravity.TOP
            setText(prefs.getString("message", DEFAULT_MESSAGE))
            hint = "متن پیامک"
        }
        layout.addView(message, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 150))
        layout.addView(TextView(this).apply { text = "سیم‌کارت ارسال‌کننده"; textSize = 18f; setPadding(0, 24, 0, 8) })
        sim = Spinner(this)
        layout.addView(sim)
        val save = Button(this).apply {
            text = "ذخیره تنظیمات"
            setOnClickListener {
                prefs.edit().putString("message", message.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "تنظیمات ذخیره شد", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(save)
        layout.addView(TextView(this).apply {
            text = "نکته: تشخیص تماس ردشده و تماس بی‌پاسخ در اندروید همیشه از هم قابل تفکیک نیست؛ در هر دو حالت پیامک ارسال می‌شود. ارسال پیامک ممکن است هزینه اپراتور داشته باشد."
            textSize = 13f
            setPadding(0, 24, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun hasPermissions() =
        checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED &&
        checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED

    private fun loadSims() {
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            sim.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("ابتدا دسترسی تماس را بدهید"))
            return
        }
        try {
            val manager = getSystemService(TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            subscriptions = manager.activeSubscriptionInfoList ?: emptyList()
            val labels = subscriptions.mapIndexed { index, info ->
                val name = info.displayName?.toString()?.takeIf { it.isNotBlank() } ?: "سیم‌کارت ${index + 1}"
                "$name (شکاف ${info.simSlotIndex + 1})"
            }.ifEmpty { listOf("سیم‌کارت پیش‌فرض گوشی") }
            sim.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
            val saved = prefs.getInt("subId", -1)
            val selected = subscriptions.indexOfFirst { it.subscriptionId == saved }
            if (selected >= 0) sim.setSelection(selected)
            sim.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    if (position < subscriptions.size) prefs.edit().putInt("subId", subscriptions[position].subscriptionId).apply()
                }
            }
        } catch (_: SecurityException) {
            sim.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("دسترسی سیم‌کارت لازم است"))
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        loadSims()
        if (!hasPermissions()) Toast.makeText(this, "برای کارکرد برنامه، دسترسی تماس و پیامک لازم است.", Toast.LENGTH_LONG).show()
    }

    companion object {
        const val DEFAULT_MESSAGE = "سلام، وقتتون بخیر 🌹\nدر حال حاضر امکان پاسخگویی به تماس شما رو ندارم. در اولین فرصت با شما تماس می‌گیرم.\nممنون از تماس شما."
    }
}
